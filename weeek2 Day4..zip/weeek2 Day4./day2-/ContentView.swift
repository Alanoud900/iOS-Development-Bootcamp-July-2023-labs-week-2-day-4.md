

import SwiftUI

let bookList: Array<String> = """
A Beautifully Foolish Endeavor
Absolution Gap
Accelerando
Acidity
Across the Universe
After Doomsday
Against the Fall of Night
An Age
"""
.components(separatedBy: "\n")

enum CardCategory{
    case Book
    case electronics
}
struct CardData: Identifiable {
    let id: UUID = UUID()
    let title: String
    let price: Int
    var category:CardCategory
    let imageURL: URL? // Optional<URL>
}
func MakeCardData() ->Array<CardData> {
    return
    bookList.map{ book in
        CardData(title: book,
                 price: 10,
                 category:.Book,
                 imageURL:URL(string: "https://source.unsplash.com/200x200/?\(book)")
        )
    }
  /*  Array(
        repeating:
            CardData(title: "Titel + Book",
                     price: 10,
                     category:.Book,
                     imageURL:URL(string: "https://source.unsplash.com/200x200/?book")
            ),
        count: 10
        )*/ +
    Array(
        repeating:
            CardData(title: "Titel + electronics",
                     price: 10,
                     category:.electronics,
                     imageURL:URL(string: "https://source.unsplash.com/200x200/?electronics")
                
            ),
        count:10
    )
}

struct CardView: View {
    let data: CardData
    var body: some View {
        GeometryReader { geometryProxy in
            ZStack{
                AsyncImage(url: data.imageURL){
                    result in
                    if let image = result.image{
                        image
                            .resizable()
                            .scaledToFill()
                    }else{
                        ProgressView()
                    }
                }
                .frame(width: geometryProxy.size.width,
                       height: geometryProxy.size.height
                )
                VStack{
                    Spacer()
                    Text(data.title)
                        .frame(maxWidth: .infinity, alignment: .leading)
                }
                .padding(8)
                .foregroundColor(.white)
                .background(
                    Gradient(colors:[
                        Color.clear,
                        Color.clear,
                        Color.clear,
                        Color.black
                    ])
                    
                )
            }
            .cornerRadius(12)
            .frame(width: geometryProxy.size.width,
                   height: geometryProxy.size.height)
            
}
}
}
    
struct ContentView : View {
    let categories : Array<String> = [
        "Book",
        "electronics"
    ]
    let cards: Array<CardData> = MakeCardData()
   @State var filteredCardss:Array<CardData> = []
    @State var searchedText:String = ""
    var bookCardData : Array<CardData> {
        cards.filter({ card in
            card.category == .Book })
    }
        
        func prepareDataForUser(){
             filteredCardss = cards
        }
        var body: some View {
            NavigationStack{
                VStack {
                    
                    HStack {
                        Image(systemName: "swift")
                        TextField("Search", text: $searchedText)
                            .frame(height: 40)
                    }
                    .padding(.vertical, 8)
                    .padding(.horizontal, 4)
                    .background(Color.gray.opacity(0.3))
                    .cornerRadius(12)
                    
                    ScrollView(.horizontal){
                        HStack{
                            ForEach(categories,id:
                                        \.self)
                            {
                                categories in
                                Button(action: {
                                    switch
                                    categories {
                                    case "Book":
                                        filteredCardss=cards.filter({card in card.category == .Book})
                                    case "electronics":
                                        filteredCardss=cards.filter({card in card.category == .electronics})
                                    default:
                                        filteredCardss = cards
                                        
                                    }
                                },
                                       label: {
                                    Text(categories)
                                        .padding(.vertical,8)
                                        .padding(.horizontal,16)
                                        .background(Color.gray.opacity(0.3))
                                        .foregroundColor(Color.black)
                                        .cornerRadius(12)
                                })
                            }
                        }
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                    ScrollView {
                        
                        CardView(
                            data: CardData(
                                title: "book and moer",
                                
                                price: 0,
                                category: .Book,
                                imageURL: URL(string: "https://source.unsplash.com/500x300/?book")
                            )
                        )
                        .frame(height: 200)
                        .clipped()
                        ScrollView(.horizontal) {
                            HStack {
                                ForEach(filteredCardss){
                                    card in
                                    if card.category == .Book {
                                        
                                        CardView(data: card)
                                            .frame(width: 300, height: 150)
                                    }
                                }
                            }
                        }
                        HStack {
                            Text("Book")
                            Spacer()
                            NavigationLink(
                                destination: {
                                    TextField("Search", text:$searchedText)
                                        .frame(height: 40)
                                        .padding(.vertical, 8)
                                        .padding(.horizontal, 4)
                                        .background(Color.gray.opacity(0.3))
                                        .cornerRadius(12)
                                    List(bookCardData){ card in
                                        NavigationLink(destination: {
                                            Text(card.title)
                                                .foregroundColor(Color.red)
                                        }, label: {
                                            Text(card.title)
                                                .foregroundColor(Color.blue)
                                        }
                                        )
                                    }
                                },
                                
                                label: {
                                    Text("See All >")
                                }
                            )
                        }
                        ScrollView(.horizontal) {
                            HStack {
                                ForEach(filteredCardss){
                                    card in
                                    if card.category == .electronics {
                                        
                                        CardView(data: card)
                                            .frame(width: 300, height: 150)
                                    }
                                }
                            }
                        }
                        HStack {
                            Text("electronics")
                            Spacer()
                            NavigationLink(
                                destination: {
                                    Text("Hello, am second view")
                                },
                                label: {
                                    Text("See All >")
                                }
                            )
                        }
                    }
                    
                    .padding(8)
                    .frame(maxWidth: .infinity, maxHeight:.infinity)
                }
                .navigationTitle("Library")
                .navigationBarTitleDisplayMode(.inline)
                
                .onAppear{
                    prepareDataForUserss()
                }
                
                .onChange(of: searchedText ){ value in
                    filteredCards(value)
                }
                
            }
        }
        func prepareDataForUserss() {
            filteredCardss = cards
        }
        func filteredCards(_ value :  String){
            if value.isEmpty {
                filteredCardss = cards
            }else {
                let lowercasedValue =
                value.lowercased()
                filteredCardss = cards.filter({ card in
                    return card.title.lowercased().contains(lowercasedValue)
                })
                }
            }
        }
    

    struct ContentView_Previews: PreviewProvider {
        static var previews: some View {
            NavigationStack{
                TabView{
                    ContentView()
                        .tabItem{
                            Label("1",systemImage: "tray.and.arrow.down.fill")
                        }
                    ProfileView().tabItem{
                        Label("2",systemImage: "tray.and.arrow.down.fill")
                    }
                }
            }
            

        }
        }


struct ProfileView: View {
    let arrayOfNumbers: Array<String> =
    Array(0...9).map { number in
        number.description}
    var body: some View {
        Form{
            Section("number of book"){
                List(arrayOfNumbers ,id:\.self){
                    number in NavigationLink(destination: {
                        Text(number).foregroundColor(.red)
                    }, label: {
                        Text(number)
                    })
                }
                }
            
            }
        
        }
    }

