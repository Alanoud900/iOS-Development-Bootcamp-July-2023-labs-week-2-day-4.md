//
//  day2_App.swift
//  day2-
//
//  Created by Alanoud  on 13/01/1445 AH.
//

import SwiftUI

@main
struct day2_App: App {
    var body: some Scene {
        WindowGroup {
        ContentView()
            
        }
    }
}
